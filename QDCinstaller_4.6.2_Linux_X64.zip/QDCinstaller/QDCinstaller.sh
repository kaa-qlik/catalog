#!/bin/bash

# Usage:   QDCinstaller.sh
#
# Options: -s   silent operation for batch run or builds
#          -o   offline installation for servers without Internet access 
#          -u   upgrade an existing Data Catalyst installation


# code checks (remove 'x'):
# xshellcheck -S error QDCinstaller.sh
# xshellcheck -S warning QDCinstaller.sh
# xshellcheck -S info -e SC2086,SC2016,SC2162 QDCinstaller.sh

error_exit() {
    echo "$1" 1>&2
    exit 1
}

# perform a variety of PostgreSQL checks
postgres_check() {
    if hash psql 2>/dev/null; then
        psql --version|grep "11\.2" 2> /dev/null
        PSQL_CHECK=$?
        if [[ $PSQL_CHECK == 0 ]]
        then
            echo "    PostgreSQL psql version 11.2 found"

            export PGPASSWORD=$SUPERUSER_PASSWORD
            psql -h $POSTGRES_HOSTNAME template1 -U $SUPERUSER_NAME -c "SELECT catalog_name, schema_name, schema_owner FROM INFORMATION_SCHEMA.SCHEMATA;" > /dev/null 2>&1
            PSQL_CHECK=$?
            if [[ $PSQL_CHECK == 0 ]]
            then
                echo "    PostgreSQL test query successfully executed using SUPERUSER_NAME and SUPERUSER_PASSWORD"
            else
                echo "Error: Invalid PostgreSQL SUPERUSER_NAME or SUPERUSER_PASSWORD, or"
                echo "       PostgreSQL security not configured per the install guide"
                echo '       Try this test: PGPASSWORD=$SUPERUSER_PASSWORD && psql -h $POSTGRES_HOSTNAME template1 -U $SUPERUSER_NAME -c "SELECT catalog_name, schema_name, schema_owner FROM INFORMATION_SCHEMA.SCHEMATA;"'
                exit 1
            fi
        else
            echo "Error: PostgreSQL psql version 11.2 not found, was PostgreSQL 11.2 installed per the install guide?"
            exit 1
        fi
    else
        echo "Error: PostgreSQL psql not found, was PostgreSQL 11.2 installed per the install guide?"
        exit 1
    fi
}

# Setup installer: process cmd line args, properties file, user input, setup logging
setup(){
# Read in script arguments
     while getopts ":su" opt; do
        case $opt in
           s) echo "" 
              echo "Silent mode detected for install"
              echo ""
              SILENTMODE=TRUE
              ;;
	       u) echo ""
              echo "Upgrade mode detected for install"
              echo ""
              UPGRADEMODE=TRUE
              ;;
           *) echo ""
              echo "Illegal argument $opt"
              echo ""
              exit 1
              ;;
        esac
    done

# Read in installer properties file
    if [ -e QDCinstaller.properties ] ; then
        set -o allexport
        # shellcheck disable=SC1091
        source QDCinstaller.properties
        set +o allexport
    else
        echo "ERROR: QDCinstaller.properties must be present"
        exit 1
    fi

# setup logging
    if [ -e QDCinstaller.log ]
    then
        rm ./QDCinstaller.log
    fi
    output_file=QDCinstaller.log
    exec > >(tee $output_file)
    exec 2>&1

    DATESTAMP=$(date +"%Y_%m_%d_%H_%M_%S")

# Check for existing installation (using core_env.properties file)

    if [ ! $UPGRADEMODE ]; then
    if [ -f $TOMCAT_HOME/conf/core_env.properties ]
    then
        echo ""
        echo ""
        echo "Info: An existing version of Qlik Catalog appears to be present."
        echo ""
        echo "      QDCinstaller.sh should be run in 'upgrade mode' to upgrade the existing version."
        echo ""
        echo "      If your intention is to upgrade Qlik Catalog please re-run the QDCinstaller.sh using the '-u' option"
        echo
        echo "      Example:  ./QDCinstaller.sh -u"
        echo ""
        read -p "Do you wish to continue with first time installation of Qlik Catalog? [y/N] " -n 1 -r
        echo ""
        echo ""
        if [[ $REPLY =~ ^[Yy]$ ]]
        then
            echo ""
            echo "Continuing with installation..."
            echo ""
            echo ""
        else
            echo "Exiting the installer"
            exit 1
        fi
    fi
fi  
# If not Single Node or Docker get HADOOP_VERSION
    if [[ $INSTALL_TYPE != "SINGLE" && $INSTALL_TYPE != "DOCKER" ]]
    then
           HADOOP_VERSION=$(hadoop version |head -n 1|awk '{print $2}')
    fi

# IF -s "silentmode" argument is not present prompt Manually set variables in properties file
    if [ ! $SILENTMODE ]
    then
        echo "Edit value or press Return to confirm value (ctrl-c to exit)"

# Confirm INSTALL_TYPE is correct
        INPUT=""
        while [ "$INPUT" != "valid" ]
        do
            echo ""
            read -p "Confirm INSTALL_TYPE=" -ei $INSTALL_TYPE INSTALL_TYPE
# Validate INSTALL_TYPE against Hadoop libraries
            if [[ $INSTALL_TYPE == "HDP" ]]
            then
                if [[ $HADOOP_VERSION == *"cdh"* ]]
                then
                    echo "ERROR: HDP install requested but Cloudera Hadoop installation detected, please check your hadoop environment and run installation again."
                exit 1
                fi
		if [[ $HADOOP_VERSION == *"amzn"* ]]
		then
		    echo "ERROR: HDP install requested but Amazon Web Services EMR Hadoop installation detected, please check your hadoop environment and run installation again."
		exit 1
		else
		    HDP_VERSION=$(hdp-select|grep hadoop-client|awk '{print $3}')
                fi
            fi
	    if [[ $INSTALL_TYPE == "CDH" ]]
            then
                exec 2>/dev/null
                ANSWER=$(hdp-select|grep hadoop-client|awk '{print $3}')
                exec 2>/dev/tty
                if [[  $ANSWER != "" ]]
                then
                    echo "ERROR: Cloudera install requested but HDP Hadoop installation detected, please check your hadoop environment and run installation again."
                exit 1
                fi
	        if [[ $HADOOP_VERSION == *"amzn"* ]]
            	then
                    echo "ERROR: HDP install requested but Amazon Web Services EMR Hadoop installation detected, please check your hadoop environment and run installation again."
                exit 1            
	        fi
	    fi

	    if [[ $INSTALL_TYPE == "EMR" ]]
            then
		exec 2>/dev/null
                ANSWER=$(hdp-select|grep hadoop-client|awk '{print $3}')
                exec 2>/dev/tty
                if [[  $ANSWER != "" ]]
                then
                    echo "ERROR: EMR install requested but HDP Hadoop installation detected, please check your hadoop environment and run installation again."
                exit 1
		fi
                if [[ $HADOOP_VERSION == *"cdh"* ]]
                then
                    echo "ERROR: EMR install requested but Cloudera Hadoop installation detected, please check your hadoop environment and run installation again."
                exit 1
		fi
            fi

	    if [[ $INSTALL_TYPE == "HDP" || $INSTALL_TYPE == "CDH" || $INSTALL_TYPE == "EMR" || $INSTALL_TYPE == "SINGLE" || $INSTALL_TYPE == "DOCKER" ]] 
            then
                INPUT="valid"
        
            else    
                echo ""
                echo "ERROR: Invalid INSTALL_TYPE specified in QDCInstaller.properties, exiting installer"
                echo ""
                exit 1

       fi
        done

# Check that QDC_HOME path is correct

        INPUT=""
        while [ "$INPUT" != "valid" ]
        do
             read -p "Confirm QDC_HOME=" -ei $QDC_HOME QDC_HOME
             if [ -d $QDC_HOME ]
             then
                 INPUT="valid"
             else
                 echo "Cannot find QDC_HOME, please check path and enter again"
             fi
        done
        permissions_check_qdc-home

# Check that Tomcat path is correct
        INPUT=""
        while [ "$INPUT" != "valid" ]
        do
             read -p "Confirm TOMCAT_HOME=" -ei $TOMCAT_HOME TOMCAT_HOME
             if [ -d $TOMCAT_HOME ]
             then
                 INPUT="valid"
             else
                 echo "Cannot find Tomcat, please check path and enter again"
             fi
        done
        permissions_check

# Get podium release zip
if [[ $INSTALL_TYPE == "HDP" || $INSTALL_TYPE == "CDH" || $INSTALL_TYPE == "EMR" || $INSTALL_TYPE == "SINGLE" || $INSTALL_TYPE == "DOCKER" ]]
    then

        INPUT=""
        while [ "$INPUT" != "valid" ]
        do
            read -p "Confirm PODIUM_RELEASE_FILE=" -ei $PODIUM_RELEASE_FILE PODIUM_RELEASE_FILE
            if [ -e $PODIUM_RELEASE_FILE ] ; then
                INPUT="valid"
            else
                echo "Cannot find file, please enter a valid path to the release zip"
        fi
        done
fi
# Check WEBAPP_NAME is set and present if upgrade
        INPUT=""
        while [ "$INPUT" != "valid" ]
        do
            read -p "Confirm WEBAPP_NAME=" -ei $WEBAPP_NAME WEBAPP_NAME
            if [[ $UPGRADEMODE && ! -d $TOMCAT_HOME/webapps/$WEBAPP_NAME ]]
            then
                echo "$TOMCAT_HOME/webapps/$WEBAPP_NAME does not exist, please revise WEBAPP_NAME"
            else
                INPUT="valid"
            fi
       done

# Check POSTGRES_HOSTNAME is set
        read -p "Confirm POSTGRES_HOSTNAME=" -ei $POSTGRES_HOSTNAME POSTGRES_HOSTNAME
        if
       INPUT=""
        then [ "$INPUT" != "valid" ]
        fi

# Database variable validation

        read -e -i "$SUPERUSER_NAME" -p "Confirm PostgreSQL SUPERUSER_NAME=" SUPERUSER_NAME

  	    if [[ "$SUPERUSER_PASSWORD" != "" ]]
        then
            read -e -i "$SUPERUSER_PASSWORD" -p "Confirm PostgreSQL SUPERUSER_PASSWORD=" SUPERUSER_PASSWORD
        else
            while [ "$SUPERUSER_PASSWORD" == "" ]
            do
                read -e -s -i "$SUPERUSER_PASSWORD" -p "Confirm PostgreSQL SUPERUSER_PASSWORD=" SUPERUSER_PASSWORD
                echo ""
            done
        fi

        postgres_check

if [ ! $UPGRADEMODE ]
    then

# Check JAVA_HOME is set and java is working
            INPUT=""
            while [ "$INPUT" != "valid" ]
            do
                read -p "Confirm JAVA_HOME=" -ei $JAVA_HOME JAVA_HOME
                if [[ -e $JAVA_HOME/bin/java ]]
                then

                    if [[ $($JAVA_HOME/bin/java -version 2>&1) = *"1.8"* || $($JAVA_HOME/bin/java -version 2>&1) = *"11."* ]]
                    then
                        INPUT="valid"
                    else
                        echo "$JAVA_HOME/bin/java -version not detecting Java 8 or 11, please correct JAVA_HOME"
                    fi

                else
                    echo "$JAVA_HOME/bin/java not found, please correct JAVA_HOME"
                fi
            done

# Get Podium Base
        read -p "Confirm PODIUM_BASE=" -ei $PODIUM_BASE PODIUM_BASE
        if
	   INPUT=""
        then [ "$INPUT" != "valid" ]
        fi

# Check ENABLE_SENSE_INTEGRATION is set
        read -p "Confirm ENABLE_SENSE_INTEGRATION=" -ei $ENABLE_SENSE_INTEGRATION ENABLE_SENSE_INTEGRATION
        if
       INPUT=""
        then [ "$INPUT" != "valid" ]
        fi

# Check ENABLE_NEXTGEN_XML is set
        read -p "Confirm ENABLE_NEXTGEN_XML=" -ei $ENABLE_NEXTGEN_XML ENABLE_NEXTGEN_XML
        if
       INPUT=""
        then [ "$INPUT" != "valid" ]
        fi

# FOR EMR set hive.alterTableToCorrectType=False

# GET URI's if left blank they will be commented out in core_env.properties
# DISTRIBUTIION_URI not needed in single server
            if [[ ! $INSTALL_TYPE == "SINGLE" && ! $INSTALL_TYPE == "DOCKER" ]]
            then
                read -e -i "$DISTRIBUTION_URI" -p "Confirm DISTRIBUTION_URI=" DISTRIBUTION_URI
            fi

# BASE URI
	    if [[ "$BASE_URI" != "" ]]
            then
                read -e -i "$BASE_URI" -p "Confirm BASE_URI=" BASE_URI
	    fi    
	    if [ $INSTALL_TYPE == "EMR" ]
            then
	        while [ "$BASE_URI" == "" ]
   	        do
	            echo "BASE_URI is required for EMR installations"
	            read -e -i "$BASE_URI" -p "Confirm BASE_URI=" BASE_URI 
	        done
	    fi
	    LOADINGDOCK_URI=$BASE_URI
	    ARCHIVE_URI=$BASE_URI
	    RECEIVING_URI=$BASE_URI
	    SHIPPINGDOCK_URI=$BASE_URI
	fi
    else
# Test these variables set in properties files if using silent mode
# Test INSTALL_TYPE

    if [[ $INSTALL_TYPE == "HDP" ]]
    then
        if [[ $HADOOP_VERSION == *"cdh"* ]]
           then
           echo "ERROR: HDP install requested but Cloudera Hadoop installation detected, please check your hadoop environment and run installation again."
           exit 1
	fi
	if [[ $HADOOP_VERSION == *"amzn"* ]]
           then
           echo "ERROR: HDP install requested but Amazon Web Services EMR Hadoop installation detected, please check your hadoop environment and run installation again."
           exit 1
           else
            HDP_VERSION=$(hdp-select|grep hadoop-client|awk '{print $3}')
        fi
    fi
    if [[ $INSTALL_TYPE == "CDH" ]]
    then
        exec 2>/dev/null
        ANSWER=$(hdp-select|grep hadoop-client|awk '{print $3}')
        exec 2>/dev/tty
        if [[  $ANSWER != "" ]]
        then
            echo "ERROR: Cloudera install requested but HDP Hadoop installation detected, please check your hadoop environment and run installation again."
        exit 1
	fi
	if [[ $HADOOP_VERSION == *"amzn"* ]]
           then
           echo "ERROR: HDP install requested but Amazon Web Services EMR Hadoop installation detected, please check your hadoop environment and run installation again."
           exit 1
        fi
    fi


            if [[ $INSTALL_TYPE == "EMR" ]]
            then
                exec 2>/dev/null
                ANSWER=$(hdp-select|grep hadoop-client|awk '{print $3}')
                exec 2>/dev/tty
                if [[  $ANSWER != "" ]]
                then
                    echo "ERROR: EMR install requested but HDP Hadoop installation detected, please check your hadoop environment and run installation again."
                exit 1
                fi
                if [[ $HADOOP_VERSION == *"cdh"* ]]
                then
                    echo "ERROR: EMR install requested but Cloudera Hadoop installation detected, please check your hadoop environment and run installation again."
                exit 1
                fi
            fi


    if [[ $INSTALL_TYPE != "HDP" && $INSTALL_TYPE != "CDH" && $INSTALL_TYPE != "EMR" && $INSTALL_TYPE != "DOCKER" && $INSTALL_TYPE != "SINGLE" ]]
    then
        echo ""
        echo "ERROR: Invalid INSTALL_TYPE specified in QDCInstaller.properties, exiting installer"
        echo ""
        exit 1
    fi

# TEST JAVA_HOME
	if [ ! $UPGRADEMODE ]
	then
            if [[ ! -e $JAVA_HOME/bin/java || ! $($JAVA_HOME/bin/java -version 2>&1) = *"1.8"* ]]
            then
                echo ""
                echo "-------------------------------------------------------------------------------------------------"
                echo "Java command failing using the current path, please correct JAVA_HOME in QDCinstaller.properties."
                echo "JAVA_HOME=" $JAVA_HOME
                echo "-------------------------------------------------------------------------------------------------"
                echo "ERROR: Installation Failed exiting installer"
                exit 1
	     fi
 	fi

# TEST QDC_HOME

        if [ ! -d $QDC_HOME ]
        then
            echo ""
            echo "-------------------------------------------------------------------------"
            echo "Cannot find the QDC home directory, please correct QDC_HOME in QDCinstaller.properties"
            echo "-------------------------------------------------------------------------"
            echo "ERROR: Installation Failed exiting installer"
            exit 1
        fi



# TEST TOMCAT_HOME
        if [ ! -d $TOMCAT_HOME ]
        then
            echo ""
            echo "-------------------------------------------------------------------------"
            echo "Cannot find Tomcat, please correct TOMCAT_HOME in QDCinstaller.properties"
            echo "-------------------------------------------------------------------------"
            echo "ERROR: Installation Failed exiting installer"
            exit 1
        fi

# Test PODIUM_RELEASE_FILE
if [[ $INSTALL_TYPE == "HDP" && $INSTALL_TYPE == "CDH" && $INSTALL_TYPE == "EMR" && $INSTALL_TYPE == "SINGLE" ]]
        then
        if [ ! -e $PODIUM_RELEASE_FILE ] ; then
            echo ""
            echo "---------------------------------------------------------------------------"
            echo "Cannot find PODIUM_RELEASE_FILE, please correct in QDCinstaller.properties."
            echo "PODIUM_RELEASE_FILE=" $PODIUM_RELEASE_FILE
            echo "---------------------------------------------------------------------------"
            echo "ERROR: Installation Failed exiting installer"
            exit 1
        fi
        else
            echo "---------------------------------------------------------------------------"
            echo "Docker installation detected - skipping check for PODIUM_RELEASE_FILE."
            echo "---------------------------------------------------------------------------" 
        fi

# Test + Set URI's if needed
	if [ !  -z $BASE_URI ]
 	then
	    LOADINGDOCK_URI=$BASE_URI
            ARCHIVE_URI=$BASE_URI
            RECEIVING_URI=$BASE_URI
            SHIPPINGDOCK_URI=$BASE_URI
	fi
 	if [ $INSTALL_TYPE == "EMR" ]
        then
	     if [[ -z $BASE_URI ]]
	     then
		echo ""
#		echo "ERROR: BASE_URI, BASE_URI_ACCOUNT, BASE_URI_PASSWORD must be set for EMR installations exiting the installer"
		echo "ERROR: BASE_URI must be set for EMR installations exiting the installer"
		exit 1
	     fi
	fi

    fi

# Check that Tomcat 7 is not being used for HDP 3.x installations

    if [[ $INSTALL_TYPE == "HDP" && $HDP_VERSION == 3* && $TOMCAT_VERSION == 7* ]]
    then
        echo ""
        echo "ERROR: Tomcat 8.5 must be used when the cluster is running HDP 3.x"
        echo "       Please see the install guide"
        echo ""
        exit 1
    fi

# Check that Tomcat 7 is not being used for CDH 6.x installations

    if [[ $INSTALL_TYPE == "CDH" && $HADOOP_VERSION == *"cdh6"* && $TOMCAT_VERSION == 7* ]]
    then
        echo ""
        echo "ERROR: Tomcat 9.0.33 must be used when the cluster is running CDH 6.x"
        echo "       Please see the install guide"
        echo ""
        exit 1
    fi

}

# Check that $QDC_HOME is writable by the current user
permissions_check_qdc-home() {
    echo "    Checking permission to $QDC_HOME"
    if [ -w $QDC_HOME ]
    then
      echo "    Permissions are good"
    else
      echo "    Permissions are not set for current user to write to that folder."
      echo "    Please correct before running the installer again."
      exit 1
    fi
     }	

# Check that  $TOMCAT_HOME is writable by the current user
permissions_check() {
    echo "    Checking permission to $TOMCAT_HOME"
    if [ -w $TOMCAT_HOME ]
    then
      echo "    Permissions are good"
    else
      echo "    Permissions are not set for current user to write to that folder."
      echo "    Please correct before running the installer again."
      exit 1
    fi

    TOMCAT_VERSION=$(java -cp $TOMCAT_HOME/lib/catalina.jar org.apache.catalina.util.ServerInfo | grep "Server number" | awk '{print $3}')
    retVal=$?
    if [ $retVal -ne 0 ]; then
        echo "    Could not determine Tomcat version"
    else
        echo "    Tomcat version is $TOMCAT_VERSION"
    fi

# Remove any obsolete .bat files from the Tomcat bin folder
   if ls $TOMCAT_HOME/bin/*.bat > /dev/null 2>&1
   then 
       rm $TOMCAT_HOME/bin/*.bat
   fi
}

# Generate setenv.sh config file 
create_setenv.sh() {
    if [ -f $TOMCAT_HOME/bin/setenv.sh ]
    then
        echo "Info: $TOMCAT_HOME/bin/setenv.sh already exists, not re-creating"
        echo ""
        return
    fi

# Set JAVA_HOME for all installs
    echo 'export JAVA_HOME='$JAVA_HOME > $TOMCAT_HOME/bin/setenv.sh
    echo '' >> $TOMCAT_HOME/bin/setenv.sh

# Set HDP version if HDP install

     if [[ $INSTALL_TYPE == "HDP" ]]
    then
        echo "export HDP_VERSION=$HDP_VERSION" >> $TOMCAT_HOME/bin/setenv.sh
        echo '' >> $TOMCAT_HOME/bin/setenv.sh
    fi

# Set PODIUM_EXTERNAL_CLASSPATH
    if [[ ! $INSTALL_TYPE == "SINGLE" && ! $INSTALL_TYPE == "DOCKER" ]]
    then
        echo -e "export PODIUM_EXTERNAL_CLASSPATH=\`hadoop classpath | sed -e 's/:/,/g' -e 's/*/*.jar/g' -e 's/*.jar.jar/*.jar/g'\`" >> $TOMCAT_HOME/bin/setenv.sh
    fi

    if [[ $INSTALL_TYPE == "HDP" ]]
    then
        echo 'export PODIUM_EXTERNAL_CLASSPATH="$PODIUM_EXTERNAL_CLASSPATH,/usr/hdp/$HDP_VERSION/hive/lib/hive-exec.jar,/usr/hdp/$HDP_VERSION/hive/lib/hive-jdbc.jar"' >> $TOMCAT_HOME/bin/setenv.sh
        echo 'export PODIUM_EXTERNAL_CLASSPATH="$PODIUM_EXTERNAL_CLASSPATH,/usr/hdp/$HDP_VERSION/hive/lib/hive-metastore.jar,/usr/hdp/$HDP_VERSION/hive/lib/hive-service.jar"' >> $TOMCAT_HOME/bin/setenv.sh
        echo 'export PODIUM_EXTERNAL_CLASSPATH="$CATALINA_BASE/podiumLibPreHadoop/*.jar,$PODIUM_EXTERNAL_CLASSPATH,$CATALINA_BASE/podiumLibPostHadoop/*.jar"' >> $TOMCAT_HOME/bin/setenv.sh
    fi

    if [[ $INSTALL_TYPE == "HDP" && $HDP_VERSION == 3* && $($JAVA_HOME/bin/java -version 2>&1) = *"11."* ]]
    then
        echo '# NOTE: activation-1.1.1.jar and groovy-all-2.4.8.jar may need to be updated to match the versions present on the edge node' >> $TOMCAT_HOME/bin/setenv.sh
        echo 'export PODIUM_EXTERNAL_CLASSPATH="$PODIUM_EXTERNAL_CLASSPATH,/usr/hdp/$HDP_VERSION/spark2/jars/activation-1.1.1.jar,/usr/hdp/$HDP_VERSION/pig/lib/groovy-all-2.4.8.jar"' >> $TOMCAT_HOME/bin/setenv.sh
    fi

    if [[ $INSTALL_TYPE == "CDH" ]]
    then
        echo 'export PODIUM_EXTERNAL_CLASSPATH="$PODIUM_EXTERNAL_CLASSPATH,/opt/cloudera/parcels/CDH/lib/hive/lib/hive-exec.jar,/opt/cloudera/parcels/CDH/lib/hive/lib/hive-jdbc.jar"' >> $TOMCAT_HOME/bin/setenv.sh
        echo 'export PODIUM_EXTERNAL_CLASSPATH="$PODIUM_EXTERNAL_CLASSPATH,/opt/cloudera/parcels/CDH/lib/hive/lib/hive-metastore.jar,/opt/cloudera/parcels/CDH/lib/hive/lib/hive-service.jar"' >> $TOMCAT_HOME/bin/setenv.sh
    fi
    if [[ $INSTALL_TYPE == "CDH" && $HADOOP_VERSION == *"cdh6"* ]]
    then
        echo 'export PODIUM_EXTERNAL_CLASSPATH="$PODIUM_EXTERNAL_CLASSPATH,/opt/cloudera/parcels/CDH/lib/pig/*.jar,/opt/cloudera/parcels/CDH/lib/pig/lib/*.jar"' >> $TOMCAT_HOME/bin/setenv.sh
    fi
    if [[ $INSTALL_TYPE == "CDH" ]]
    then
        echo 'export PODIUM_EXTERNAL_CLASSPATH="$CATALINA_BASE/podiumLibPreHadoop/*.jar,$PODIUM_EXTERNAL_CLASSPATH,$CATALINA_BASE/podiumLibPostHadoop/*.jar"' >> $TOMCAT_HOME/bin/setenv.sh
    fi

    if [[ $INSTALL_TYPE == "EMR" ]]
    then
        echo 'export PODIUM_EXTERNAL_CLASSPATH="$PODIUM_EXTERNAL_CLASSPATH,/usr/lib/hadoop/client/*.jar"' >> $TOMCAT_HOME/bin/setenv.sh
        echo 'export PODIUM_EXTERNAL_CLASSPATH="$PODIUM_EXTERNAL_CLASSPATH,/usr/lib/hive/lib/hive-exec.jar,/usr/lib/hive/lib/hive-jdbc.jar"' >> $TOMCAT_HOME/bin/setenv.sh
        echo 'export PODIUM_EXTERNAL_CLASSPATH="$PODIUM_EXTERNAL_CLASSPATH,/usr/lib/hive/lib/hive-metastore.jar,/usr/lib/hive/lib/hive-service.jar"' >> $TOMCAT_HOME/bin/setenv.sh
        echo 'export PODIUM_EXTERNAL_CLASSPATH="$PODIUM_EXTERNAL_CLASSPATH,/usr/lib/pig/*.jar,/usr/lib/pig/lib/*.jar"' >> $TOMCAT_HOME/bin/setenv.sh
        echo 'export PODIUM_EXTERNAL_CLASSPATH="/usr/share/aws/emr/emrfs/lib/*.jar,$PODIUM_EXTERNAL_CLASSPATH"' >> $TOMCAT_HOME/bin/setenv.sh
        echo 'export PODIUM_EXTERNAL_CLASSPATH="$CATALINA_BASE/podiumLibPreHadoop/*.jar,$PODIUM_EXTERNAL_CLASSPATH,$CATALINA_BASE/podiumLibPostHadoop/*.jar"' >> $TOMCAT_HOME/bin/setenv.sh
    fi

# Set JAVA_OPTS

    if [[ $INSTALL_TYPE == "HDP" ]]
    then
        echo 'export JAVA_OPTS="$JAVA_OPTS -Xms1g -Xmx8g -Dhdp.version=$HDP_VERSION -Djava.library.path=/lib64/:/usr/hdp/$HDP_VERSION/hadoop/lib/native"' >> $TOMCAT_HOME/bin/setenv.sh
    fi

    if [ $INSTALL_TYPE == "CDH" ]
    then
        echo 'export JAVA_OPTS="$JAVA_OPTS -Xms1g -Xmx8g -Djava.library.path=/lib64/:/opt/cloudera/parcels/CDH/lib/hadoop/lib/native/"' >> $TOMCAT_HOME/bin/setenv.sh
    fi

    if [[ $INSTALL_TYPE == "EMR" ]]
    then
	echo 'export JAVA_OPTS="$JAVA_OPTS -Xms1g -Xmx8g -Djava.library.path=/lib64/:/usr/lib/hadoop/lib/native/:/usr/lib/hadoop-lzo/lib/native/"' >> $TOMCAT_HOME/bin/setenv.sh
    fi

    if [[ $INSTALL_TYPE == "SINGLE" || $INSTALL_TYPE == "DOCKER" ]]
    then
        echo 'export JAVA_OPTS="$JAVA_OPTS -Xms1g -Xmx8g -Dpodium.conf.dir=$CATALINA_BASE/conf"' >> $TOMCAT_HOME/bin/setenv.sh
        echo 'export JAVA_OPTS="$JAVA_OPTS -Djava.library.path=/lib64"' >> $TOMCAT_HOME/bin/setenv.sh
        echo 'export JAVA_OPTS="$JAVA_OPTS -Dpodium.conf.dir=$CATALINA_BASE/conf"' >> $TOMCAT_HOME/bin/setenv.sh
    else
        echo 'export JAVA_OPTS="$JAVA_OPTS -DPODIUM_EXTERNAL_CLASSPATH=$PODIUM_EXTERNAL_CLASSPATH -Dpodium.conf.dir=$CATALINA_BASE/conf"' >> $TOMCAT_HOME/bin/setenv.sh
    fi

# set for all installation types
    echo 'export JAVA_OPTS="$JAVA_OPTS -Djavax.security.auth.useSubjectCredsOnly=false -Djava.security.egd=file:/dev/./urandom"' >> $TOMCAT_HOME/bin/setenv.sh

# set for all except SINGLE & DOCKER
    if [[ ! $INSTALL_TYPE == "SINGLE" && ! $INSTALL_TYPE == "DOCKER" ]]
    then
        echo '' >> $TOMCAT_HOME/bin/setenv.sh
        echo 'export SPARK_MASTER=yarn-client' >> $TOMCAT_HOME/bin/setenv.sh
    fi

# Prevent Tomcat from running with root account

    sed -i -e '1i[[ $(whoami) == "root" ]] && echo "Do not run as root, run as service user (e.g., qdc)" && exit 1\' $TOMCAT_HOME/bin/setenv.sh

# Make setenv.sh executable
    chmod +x $TOMCAT_HOME/bin/setenv.sh
}

update_startup.sh(){
    if grep -q HeapDumpOnOutOfMemoryError $TOMCAT_HOME/bin/startup.sh
    then
        echo "Info: $TOMCAT_HOME/bin/startup.sh already contains HeapDumpOnOutOfMemoryError setting"
        echo ""
    else
        echo "Info: Adding heap and GC log settings to $TOMCAT_HOME/bin/startup.sh"
        echo ""
        JVM_SETTINGS_1="# uncomment for Java 8"
        JVM_SETTINGS_2="#export JAVA_OPTS=\"\$JAVA_OPTS -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=$TOMCAT_HOME/logs/\$(date '+%Y-%m-%d-%H-%M-%S').hprof -XX:+PrintGCDateStamps -verbose:gc -XX:+PrintGCDetails -Xloggc:$TOMCAT_HOME/logs/gc-\$(date '+%Y-%m-%d-%H-%M-%S').log\""
        JVM_SETTINGS_3="# uncomment for Java 11"
        JVM_SETTINGS_4="#export JAVA_OPTS=\"\$JAVA_OPTS -XX:+HeapDumpOnOutOfMemoryError -XX:HeapDumpPath=$TOMCAT_HOME/logs/\$(date '+%Y-%m-%d-%H-%M-%S').hprof -Xlog:gc:$TOMCAT_HOME/logs/gc-\$(date '+%Y-%m-%d-%H-%M-%S').log\""
        sed -i "/\#\!\/bin\/sh/a $JVM_SETTINGS_4" $TOMCAT_HOME/bin/startup.sh
        sed -i "/\#\!\/bin\/sh/a $JVM_SETTINGS_3" $TOMCAT_HOME/bin/startup.sh
        sed -i "/\#\!\/bin\/sh/a $JVM_SETTINGS_2" $TOMCAT_HOME/bin/startup.sh
        sed -i "/\#\!\/bin\/sh/a $JVM_SETTINGS_1" $TOMCAT_HOME/bin/startup.sh
    fi
}

# Update catalina.properties file
update_catalina.properties(){
    sed -i '/shared.loader=/ c\shared.loader=${PODIUM_EXTERNAL_CLASSPATH}' $TOMCAT_HOME/conf/catalina.properties 
}

# Update core_env.properties file
update_core_env.properties(){
    if [ -f $TOMCAT_HOME/conf/core_env.properties ]
    then
        echo "Info: $TOMCAT_HOME/conf/core_env.properties already exists, not re-creating"
        echo ""
        return
    fi
    if [[ $INSTALL_TYPE != "DOCKER" ]]
    then
        cp $TOMCAT_HOME/QDCinstaller/podium/config/core_env.properties $TOMCAT_HOME/conf
    else
        cp /tmp/QDCinstaller/podium/config/core_env.properties $TOMCAT_HOME/conf
    fi    


# Update Database settings in core_env.properties
    sed -i "/jdbc.url=/ c\jdbc.url=jdbc:postgresql://$POSTGRES_HOSTNAME:5432/podium_md" $TOMCAT_HOME/conf/core_env.properties
    sed -i "/jdbc.user=/ c\jdbc.user=podium_md" $TOMCAT_HOME/conf/core_env.properties
    sed -i "/jdbc.password=/ c\jdbc.password=#0{SI+N1xR0xF2wqNPsHxih6w==}" $TOMCAT_HOME/conf/core_env.properties

    sed -i "s|podium.base=podiumbuild|podium.base=$PODIUM_BASE|" $TOMCAT_HOME/conf/core_env.properties
    sed  -i  "/hadoop.conf.files=core/ c\hadoop.conf.files=$HADOOP_CONF_FILES" $TOMCAT_HOME/conf/core_env.properties
    sed -i "s|enable.archiving=true|enable.archiving=false|" $TOMCAT_HOME/conf/core_env.properties

# Update podium.LogsDir in core-env.properties
    sed -i "/podium.LogsDir=/ c\podium.LogsDir=$TOMCAT_HOME/logs" $TOMCAT_HOME/conf/core_env.properties

# Update 'localfile' access directories
    sed -i "/localfile.base.dir.source.connection=/ c\localfile.base.dir.source.connection=$QDC_HOME/source" $TOMCAT_HOME/conf/core_env.properties
    sed -i "/localfile.base.dir.publish.target=/ c\localfile.base.dir.publish.target=$QDC_HOME/publish" $TOMCAT_HOME/conf/core_env.properties

# IF EMR 
    if [ $INSTALL_TYPE == "EMR" ]
    then
        sed -i "/hive.alterTableToCorrectType=/ c\hive.alterTableToCorrectType=false" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/shippingdock.use.fulluri=/ c\shippingdock.use.fulluri=true" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/sample.data.available.engines=/ c\sample.data.available.engines=MAPREDUCE" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/explore.available.engines=/ c\explore.available.engines=MAPREDUCE" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/prepare.available.engines=/ c\prepare.available.engines=LOCAL,MAPREDUCE,TEZ" $TOMCAT_HOME/conf/core_env.properties
    fi

# No Spark or Tez on CDH6
    if [[ $INSTALL_TYPE == "CDH" && $HADOOP_VERSION == *"cdh6"* ]]
    then
        sed -i "/sample.data.available.engines=/ c\sample.data.available.engines=MAPREDUCE" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/explore.available.engines=/ c\explore.available.engines=MAPREDUCE" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/prepare.available.engines=/ c\prepare.available.engines=LOCAL,MAPREDUCE,TEZ" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/tez.lib.uris=/ c\#tez.lib.uris=hdfs://<NAME_SERVICE>:8020/<PATH>/tez-0.9.2-cdh-6.tar.gz" $TOMCAT_HOME/conf/core_env.properties
    fi

# URI's shoud be commented out if blank
# loadingdock.uri
    if [ -z $LOADINGDOCK_URI ]
    then
        sed -i "s|loadingdock.uri=|#loadingdock.uri=|" $TOMCAT_HOME/conf/core_env.properties
    else
        sed -i "/loadingdock.uri/ c\loadingdock.uri=$LOADINGDOCK_URI" $TOMCAT_HOME/conf/core_env.properties
	sed -i "/loadingdock.username/ c\loadingdock.username=$BASE_URI_USERNAME" $TOMCAT_HOME/conf/core_env.properties
	sed -i "/loadingdock.password/ c\loadingdock.password=$BASE_URI_PASSWORD" $TOMCAT_HOME/conf/core_env.properties
    fi

# archive.uri
    if [ -z $ARCHIVE_URI ]
    then
        sed -i "s|archive.uri=|#archive.uri=|" $TOMCAT_HOME/conf/core_env.properties
    else
        sed -i "/archive.uri=/ c\archive.uri=$ARCHIVE_URI" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/archive.username=/ c\archive.username=$BASE_URI_USERNAME" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/archive.password=/ c\archive.password=$BASE_URI_PASSWORD" $TOMCAT_HOME/conf/core_env.properties

    fi

# receiving.uri
    if [ -z $RECEIVING_URI ]
    then
        sed -i "s|receiving.uri=|#receiving.uri=|" $TOMCAT_HOME/conf/core_env.properties
    else
        sed -i "/receiving.uri=/ c\receiving.uri=$RECEIVING_URI" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/receiving.username=/ c\receiving.username=$BASE_URI_USERNAME" $TOMCAT_HOME/conf/core_env.properties 
        sed -i "/receiving.password=/ c\receiving.password=$BASE_URI_PASSWORD" $TOMCAT_HOME/conf/core_env.properties
    fi

# shippingdock.uri
    if [ -z $SHIPPINGDOCK_URI ]
    then
        sed -i 's|shippingdock.uri|#shippingdock.uri=|' $TOMCAT_HOME/conf/core_env.properties
    else
      sed -i "/shippingdock.uri/ c\shippingdock.uri=$SHIPPINGDOCK_URI" $TOMCAT_HOME/conf/core_env.properties
      sed -i "/shippingdock.username/ c\shippingdock.username=$BASE_URI_USERNAME" $TOMCAT_HOME/conf/core_env.properties
      sed -i "/shippingdock.password/ c\shippingdock.password=$BASE_URI_PASSWORD" $TOMCAT_HOME/conf/core_env.properties
    fi

# distribution.uri
    if [[ $INSTALL_TYPE == "SINGLE" || $INSTALL_TYPE = "DOCKER" ]]
    then
        sed -i "/^distribution.uri=/ c\distribution.uri=jdbc:postgresql://$POSTGRES_HOSTNAME:5432/podium_dist" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/^distribution.username=/ c\distribution.username=podium_dist" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/^distribution.password=/ c\distribution.password=#0{SI+N1xR0xF2wqNPsHxih6w==}" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/jdbc.hive.driver=/ c\jdbc.hive.driver=org.postgresql.Driver" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/publish.data.method=/ c\publish.data.method=PIG" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/prepare.available.engines=/ c\prepare.available.engines=LOCAL" $TOMCAT_HOME/conf/core_env.properties
        sed -i "s|^hadoop.conf.files|#hadoop.conf.files|" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/^internal.file.formats=/ c\internal.file.formats=TEXT_TAB_DELIMITED" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/hadoop.job.poolsize=/ c\hadoop.job.poolsize=5" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/entity.name.length=/ c\entity.name.length=230" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/source.name.length=/ c\source.name.length=128" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/use.single.receiving.mapper=/ c\use.single.receiving.mapper=true" $TOMCAT_HOME/conf/core_env.properties
        sed -i "/external.job.runner.spawn=/ c\external.job.runner.spawn=true" $TOMCAT_HOME/conf/core_env.properties

    else
        if [ -z $DISTRIBUTION_URI ]
        then
            sed -i "s|distribution.uri=|#distribution.uri=|" $TOMCAT_HOME/conf/core_env.properties
        else
            sed -i  "/^distribution.uri=/ c\distribution.uri=$DISTRIBUTION_URI" $TOMCAT_HOME/conf/core_env.properties
        fi
    fi

    sed -i "/qvd.openconnector.script.path=/ c\qvd.openconnector.script.path=$QDC_HOME/qlikcore/qdc_qvd_2_csv.sh %prop.qvd.file.linux.folder %prop.qvd.file.entity.original.name %loadingDockLocation %loadingDockUri" $TOMCAT_HOME/conf/core_env.properties
    sed -i "/qvd.publish.script.path=/ c\qvd.publish.script.path=$QDC_HOME/qlikcore/qdc_csv_2_qvd.sh %sourceDir %targetDir %targetFileName" $TOMCAT_HOME/conf/core_env.properties

    if [[ $INSTALL_TYPE == "HDP" && $HDP_VERSION == 3* ]]
    then
        sed -i "/#mapreduce.job.user.classpath.first=false/ c\mapreduce.job.user.classpath.first=true" $TOMCAT_HOME/conf/core_env.properties
    fi
}

# Configure metadata database
configure_podium_md() {
if [[ $INSTALL_TYPE != "SINGLE" && $INSTALL_TYPE != "DOCKER" && $CREATE_PODIUM_MD_DATABASE != "true" ]]
then
    echo "Info: Metadata database podium_md will not be created"
    echo ""
    return
fi

if [ ! $SILENTMODE ]
then
    read -n 1 -s -p "`echo -e 'Press any key to create the metadata database podium_md (it will only be created if it does not exist)'`"
    echo ""
fi

# check if database podium_md already exists
export PGPASSWORD=$SUPERUSER_PASSWORD
if [ "$( psql -h $POSTGRES_HOSTNAME template1 -U $SUPERUSER_NAME -tAc "SELECT 1 FROM pg_database WHERE datname='podium_md'" )" ]
then
    echo ""
    echo "Info: Database podium_md already exists"
    echo ""
else
    INTERNAL_DB_PASSWORD=nvs2014!
    psql -h $POSTGRES_HOSTNAME template1 -U $SUPERUSER_NAME -c "create role podium_md with encrypted password '$INTERNAL_DB_PASSWORD' createdb login;"

    export PGPASSWORD=$INTERNAL_DB_PASSWORD
    psql -h $POSTGRES_HOSTNAME template1 -U podium_md -c "create database podium_md;"
    if [ ! "$( psql -h $POSTGRES_HOSTNAME template1 -U podium_md -tAc "SELECT 1 FROM pg_database WHERE datname='podium_md'" )" ]
    then
        echo ""
        echo "-----------------------------------------------------"
        echo "ERROR: Could not create database podium_md"
        echo "-----------------------------------------------------"
        echo ""
        unset PGPASSWORD
        exit 1
    fi
    
    # check if schema podium_core already exists
    if [ "$( psql -h $POSTGRES_HOSTNAME podium_md -U podium_md -tAc "SELECT 1 FROM information_schema.schemata WHERE schema_name = 'podium_core'" )" ]
    then
        echo ""
        echo "Info: Schema podium_core already exists"
        echo ""
    else
        psql -h $POSTGRES_HOSTNAME podium_md -U podium_md -c "create schema podium_core;"
        if [ ! "$( psql -h $POSTGRES_HOSTNAME podium_md -U podium_md -tAc "SELECT 1 FROM information_schema.schemata WHERE schema_name = 'podium_core'" )" ]
        then
            echo ""
            echo "------------------------------------------"
            echo "ERROR: Could not create schema podium_core"
            echo "------------------------------------------"
            echo ""
            unset PGPASSWORD
            exit 1
        fi
    fi
    
    # check if table podium_core.pd_schema_version already exists
    if [ "$( psql -h $POSTGRES_HOSTNAME podium_md -U podium_md -tAc "SELECT 1 FROM information_schema.tables WHERE table_schema = 'podium_core' AND table_name = 'pd_schema_version'" )" ]
    then
        echo ""
        echo "Info: Table podium_core.pd_schema_version already exists"
        echo ""
    else
        if [[ $INSTALL_TYPE != "DOCKER" ]]
        then
            psql -h $POSTGRES_HOSTNAME podium_md -U podium_md -f $TOMCAT_HOME/QDCinstaller/podium/config/core_ddl.txt
            if [ ! "$( psql -h $POSTGRES_HOSTNAME podium_md -U podium_md -tAc "SELECT 1 FROM information_schema.tables WHERE table_schema = 'podium_core' AND table_name = 'pd_schema_version'" )" ]
            then
                echo ""
                echo "----------------------------------"
                echo "ERROR: Could not initialize tables"
                echo "----------------------------------"
                echo ""
                unset PGPASSWORD
                exit 1
            fi
        else
            psql -h $POSTGRES_HOSTNAME podium_md -U podium_md -f /tmp/QDCinstaller/podium/config/core_ddl.txt
            if [ ! "$( psql -h $POSTGRES_HOSTNAME podium_md -U podium_md -tAc "SELECT 1 FROM information_schema.tables WHERE table_schema = 'podium_core' AND table_name = 'pd_schema_version'" )" ]
            then
                echo ""
                echo "----------------------------------"
                echo "ERROR: Could not initialize tables"
                echo "----------------------------------"
                echo ""
                unset PGPASSWORD
                exit 1
            fi
        fi
    fi
fi
unset PGPASSWORD
}

# Configure distribution database
configure_podium_dist() {
if [ ! $SILENTMODE ]
then
    read -n 1 -s -p "`echo -e '\n\nPress any key to create or update the distribution database podium_dist'`"
    echo ""
fi

# check if database podium_dist already exists
export PGPASSWORD=$SUPERUSER_PASSWORD
INTERNAL_DB_PASSWORD=nvs2014!
if [ "$( psql -h $POSTGRES_HOSTNAME template1 -U $SUPERUSER_NAME -tAc "SELECT 1 FROM pg_database WHERE datname='podium_dist'" )" ]
then
    echo ""
    echo "Info: Database podium_dist already exists"
    echo ""
    READONLY_USER_EXISTED="$(psql -h $POSTGRES_HOSTNAME template1 -U $SUPERUSER_NAME -tAc "SELECT 1 FROM pg_roles WHERE rolname='podium_readonly'" )"
else
    psql -h $POSTGRES_HOSTNAME template1 -U $SUPERUSER_NAME -c "create role podium_dist with encrypted password '$INTERNAL_DB_PASSWORD' superuser createdb login;"

    export PGPASSWORD=$INTERNAL_DB_PASSWORD
    psql -h $POSTGRES_HOSTNAME template1 -U podium_dist -c "create database podium_dist;"
    if [ ! "$( psql -h $POSTGRES_HOSTNAME template1 -U podium_dist -tAc "SELECT 1 FROM pg_database WHERE datname='podium_dist'" )" ]
    then
        echo ""
        echo "-----------------------------------------------------"
        echo "ERROR: Could not create database podium_dist"
        echo "-----------------------------------------------------"
        echo ""
        unset PGPASSWORD
        exit 1
    fi

    READONLY_USER_EXISTED="$( psql -h $POSTGRES_HOSTNAME template1 -U $SUPERUSER_NAME -tAc "SELECT 1 FROM pg_roles WHERE rolname='podium_readonly'" )"

    # setup file_fdw and related permissions
if [[ $INSTALL_TYPE != "DOCKER" ]]    
then
    psql -h $POSTGRES_HOSTNAME podium_dist -U podium_dist -f $TOMCAT_HOME/QDCinstaller/podium/config/podium_dist_su_ddl.txt
else
    psql -h $POSTGRES_HOSTNAME podium_dist -U podium_dist -f /tmp/QDCinstaller/podium/config/podium_dist_su_ddl.txt    
fi
fi

# qlik_schema only contains functions, and so can be re-created on upgrade
export PGPASSWORD=$SUPERUSER_PASSWORD
if [[ $INSTALL_TYPE != "DOCKER" ]]
then
    psql -h $POSTGRES_HOSTNAME podium_dist -U $SUPERUSER_NAME -f $TOMCAT_HOME/QDCinstaller/podium/config/podium_dist_ddl.txt
else
    psql -h $POSTGRES_HOSTNAME podium_dist -U $SUPERUSER_NAME -f /tmp/QDCinstaller/podium/config/podium_dist_ddl.txt
fi
if [ ! "$( psql -h $POSTGRES_HOSTNAME podium_dist -U $SUPERUSER_NAME -tAc "SELECT 1 FROM information_schema.schemata WHERE schema_name = 'qlik_schema'" )" ]
then
    echo ""
    echo "----------------------------------"
    echo "ERROR: Could not initialize schema"
    echo "----------------------------------"
    echo ""
    unset PGPASSWORD
    exit 1
fi

if  [ $READONLY_USER_EXISTED ] 
then
	echo "Info: User podium_readonly already existed - omitting (re)creation and (re)configuration."
else
	echo "Info: Creating password for user podium_readonly..."
	psql -h $POSTGRES_HOSTNAME podium_dist -U $SUPERUSER_NAME -c "ALTER USER podium_readonly WITH ENCRYPTED PASSWORD '$INTERNAL_DB_PASSWORD' LOGIN NOSUPERUSER;"

# interactive.query
        if [[ $INSTALL_TYPE == "SINGLE" || $INSTALL_TYPE = "DOCKER" ]]
        then
            echo "Info: Testing whether impersonation mode is eanbled..."
            cat $TOMCAT_HOME/conf/core_env.properties | grep "^enable\.impersonation=true"
            if [[ $? == 1 ]]
            then
                echo "Info: ... impersonation not enabled - interactive query user will be initialized to the less privileged user podium_readonly..."
                sed -i "/#interactive.query.data.uri=/ c\interactive.query.data.uri=jdbc:postgresql://$POSTGRES_HOSTNAME:5432/podium_dist" $TOMCAT_HOME/conf/core_env.properties
                sed -i "/#interactive.query.data.username=/ c\interactive.query.data.username=podium_readonly" $TOMCAT_HOME/conf/core_env.properties
                sed -i "/#interactive.query.data.password=/ c\interactive.query.data.password=#0{SI+N1xR0xF2wqNPsHxih6w==}" $TOMCAT_HOME/conf/core_env.properties
                sed -i "/#interactive.query.tool.driver=/ c\interactive.query.tool.driver=org.postgresql.Driver" $TOMCAT_HOME/conf/core_env.properties
            else
                echo "Info: ... impersonation is enabled - interactive query user not reconfigured."
            fi
        fi
fi

unset PGPASSWORD
}

configure_qlik_integration() {


    if [ ! $SILENTMODE ]
    then
        read -n 1 -s -p "`echo -e 'Press any key to configure Qlik Core integration'`"
        echo ""
        echo ""
    fi

        if hash node 2>/dev/null; then
            if hash npm 2>/dev/null; then
                cd $QDC_HOME/qlikcore || error_exit "Error: cannot change directory to $QDC_HOME/qlikcore"
                if [ -d node_modules ]
                then
                    echo "Info: node modules already installed"
                    echo ""
                else
                    echo "Info: installing node modules, this takes about 15 seconds, output to npm.log"
                    npm install --only=prod > npm.log 2>&1
                    NPM_CHECK=$?
                    if [[ $NPM_CHECK == 0 ]]
                    then
                        echo "Info: node modules successfully installed, listing"
                        echo ""
                        npm ls
                        # 4.2-13466 required the following path to be replaced; this is no longer the case
                        sed -ri "s|node /usr/local/podium/qlikcore|node $QDC_HOME/qlikcore|" $QDC_HOME/qlikcore/qdc_qvd_2_csv.sh
                    else
                        echo "Error: npm install unsuccessful, exit code: $NPM_CHECK, see npm.log"
                        exit 1
                    fi
                fi
            else
                echo "Error: npm not found, were Docker and Node.js installed per the install guide?"
                exit 1
            fi
        else
            echo "Error: node not found, were Docker and Node.js installed per the install guide?"
            exit 1
        fi
    
    if hash docker 2>/dev/null; then
        if hash docker-compose 2>/dev/null; then
            cd $QDC_HOME/qlikcore || error_exit "Error: cannot change directory to $QDC_HOME/qlikcore"
            # 88c1b341af2a = qliktech-docker-experimental.jfrog.io/engine:qdc-qlik-core
            # 60c963ecd624 = qliktech-docker-experimental.jfrog.io/engine:qdc-qlik-core-feb-2020
            # load latest image
            docker images|grep 60c963ecd624 > /dev/null 2>&1
            IMAGE_CHECK=$?
            if [[ $IMAGE_CHECK == 0 ]]
            then
                echo "Info: Qlik Core Docker image already loaded"
            else
                echo "Info: loading Qlik Core Docker image"
                docker load < qdc-qlik-core-feb-2020.tar
                DOCKER_CHECK=$?
                if [[ $DOCKER_CHECK == 0 ]]
                then
                    echo "Info: Qlik Core Docker image successfully loaded, listing"
                    echo ""
                    # filter all qlik core images
                    docker images|grep -e 60c963ecd624 -e 88c1b341af2a

                    # stop old image(s)
                    docker stop qlikintegration_qix-engine_1 > /dev/null 2>&1
                    docker stop qlikcore_qix-engine_1 > /dev/null 2>&1
                   
                    # see if latest image is running
                    ( docker inspect -f '{{.State.Running}}' qlikcore_qix-engine_1 2> /dev/null ) | grep true > /dev/null 2>&1
                    INSPECT_CHECK=$?
                    if [[ $INSPECT_CHECK == 0 ]]
                    then
                        echo ""
                        echo "Info: Qlik Core already running"
                    else
                        echo ""
                        echo "Info: Starting Qlik Core"
                        ./launch_qlikcore.sh
                    fi
                else
                    echo "Error: Qlik Core Docker image load unsuccessful, exit code: $DOCKER_CHECK"
                    exit 1
                fi
            fi
        else
            echo "Error: docker-compose not found, were Docker and Node.js installed per the install guide?"
            exit 1
        fi
    else
        echo "Error: Docker not found, were Docker and Node.js installed per the install guide?"
        exit 1
    fi
}


# CONFIGURE DCAAS INTEGRATION - CONTAINER INSTALLATION (DCAAS Connectors)

configure_dcaas_integration() {

if [[ ! $SILENTMODE ]]
then
        read -n 1 -s -p "`echo -e 'Press any key to configure Qlik Nextgen XML Integration'`"
        echo ""
        echo ""
fi

# Modify core_env.properties to enable NextGen XML

sed -i "/enable.new.xml.ingestion/s/^#//" $TOMCAT_HOME/conf/core_env.properties
sed -i "/base.xml.callback.url/s/^#//" $TOMCAT_HOME/conf/core_env.properties
sed -i "/#dcaas.xml.web.dir=/ c\dcaas.xml.web.dir=$QDC_HOME/dcaasIntegration/qdc-xmlstore" $TOMCAT_HOME/conf/core_env.properties
sed -i "/#dcaas.connector.staging.dir=/ c\dcaas.connector.staging.dir=$QDC_HOME/dcaasIntegration/dcaas-connector-staging" $TOMCAT_HOME/conf/core_env.properties


# DCAAS Container
    if hash docker 2>/dev/null; then
        if hash docker-compose 2>/dev/null; then
            cd $QDC_HOME/dcaasIntegration || error_exit "Error: cannot change directory to $QDC_HOME/dcaasIntegration"
            docker images|grep dcaas > /dev/null 2>&1
            IMAGE_CHECK=$?
            if [[ $IMAGE_CHECK == 0 ]]
            then
                echo "Info: Qlik DCAAS Docker image already loaded"
            else
                echo "Info: loading Qlik DCAAS Docker image"
                docker load < qlik-dcaas.tar
                DOCKER_CHECK=$?
                if [[ $DOCKER_CHECK == 0 ]]
                then
                    echo "Info: Qlik DCAAS Docker image successfully loaded, listing"
                    echo ""
                    docker images
                else
                    echo "Error: Qlik DCAAS Docker image load unsuccessful, exit code: $DOCKER_CHECK"
                    exit 1
                fi
            fi

# Data-Connector-Rest Container

            docker images|grep data-connector-rest > /dev/null 2>&1
            IMAGE_CHECK=$?
            if [[ $IMAGE_CHECK == 0 ]]
            then
                echo "Info: Qlik 'Data-Connector-Rest' Docker image already loaded"
            else
                echo "Info: Loading Qlik 'Data-Connector-Rest' Docker image"
                docker load < data-connector-rest.tar
                DOCKER_CHECK=$?
                if [[ $DOCKER_CHECK == 0 ]]
                then
                    echo "Info: Qlik 'Data-Connector-Rest' Docker image successfully loaded, listing"
                    echo ""
                    docker images
                else
                    echo "Error: Qlik 'Data-Connector-Rest' Docker image load unsuccessful, exit code: $DOCKER_CHECK"
                    exit 1
                fi
            fi
# Launch DCAAS Integration Containers
            docker inspect -f '{{.State.Running}}' dcaas > /dev/null 2>&1
            INSPECT_CHECK=$?
            if [[ $INSPECT_CHECK == 0 ]]
            then
                echo ""
                echo "Info: Qlik DCAAS container already running"
            fi
            docker inspect -f '{{.State.Running}}' data-connector-rest > /dev/null 2>&1
            INSPECT_CHECK=$?
            if [[ $INSPECT_CHECK == 0 ]]
            then
                    echo ""
                    echo "Info: Qlik Data-Connector-Rest container already running"
            else
                echo ""
                echo "Info: Starting Qlik 'DCAAS & REST' containers"
                ./launch_dcaas_connectors.sh
            fi
        else
            echo "Error: docker-compose not found, was Docker-Compose installed per the install guide?"
            exit 1
        fi
    else
        echo "Error: Docker not found, was Docker installed per the install guide?"
        exit 1
    fi



}


# On completion print summary and if there are problems found
summary() {
    echo ""
    echo "-------"
    echo "Summary"
    echo "-------"
    echo ""
    echo "This output has been written to $output_file"
    echo ""
    if [ -n "$problem_found" ] ; then
        echo "WARNING: Problems were found, please carefully review the above output"
        echo ""
    fi
    echo "SUCCESS: The installer successfully completed, no problems were found"
    echo "         Starting Qlik Data Catalyst using ${TOMCAT_HOME}/bin/startup.sh"
    echo "         You may: tail -f ${TOMCAT_HOME}/logs/catalina.out"
    echo ""
    ${TOMCAT_HOME}/bin/startup.sh
    echo ""
}

# Press any key to continue
press-any-key(){
    echo ""
    read -n 1 -s -p "Validation completed, press any key to continue with installation"
}

# MAIN
echo "--------------"
echo " QDC Installer"
echo "--------------"
echo ""

if [[ $EUID -eq 0 ]]; then
   echo "ERROR: The installer should not be run as root. Run it as the service account user."
   exit 1
fi

echo "Environment Setup and Validation"

# Setup script pass $@ along to forward cmd line args
setup "$@"
if [ ! $SILENTMODE ]
then
    press-any-key
fi

# Shutdown Tomcat (in case its running)
echo ""
echo ""
echo "--------------------"
echo "Shutting down Tomcat"
echo "--------------------"
echo ""
$TOMCAT_HOME/bin/shutdown.sh 2> /dev/null
echo ""
echo "Tomcat shutdown completed"
echo ""

# Create Qlik Sense Integration Subdirectories

if [[ $ENABLE_SENSE_INTEGRATION == "TRUE" ]]
then
	echo ""
	echo ""
	echo "Creating Qlik Sense Integration Folders"
	echo ""
	if [ -d $QDC_HOME/qlikcore ]
    then
        echo "Info: $QDC_HOME/qlikcore already exists, not re-creating"
        echo ""
    else
	    mkdir -p "$QDC_HOME/qlikcore"
	    echo "Info: Directory $QDC_HOME/qlikcore created"
	    echo ""
	fi
	if [ -d $QDC_HOME/qlikpublish ]
    then
        echo "Info: $QDC_HOME/qlikpublish already exists, not re-creating"
        echo ""
    else
        mkdir -p "$QDC_HOME/qlikpublish"
	    echo "Info: Directory $QDC_HOME/qlikpublish created"
	    echo ""
    fi
	if [ -d $QDC_HOME/qlikpublish/certs ]
    then
        echo "Info: $QDC_HOME/qlikpublish/certs already exists, not re-creating"
        echo ""
    else
        mkdir -p "$QDC_HOME/qlikpublish/certs"
	    echo "Info: Directory $QDC_HOME/qlikpublish/certs created"
	    echo ""
	fi
fi

# Create Qlik Nextgen XML Integration Subdirectories
if [[ $ENABLE_NEXTGEN_XML == "TRUE" ]]
then
    echo ""
    echo ""
    echo "Creating Qlik Nextgen XML Integration Folders"
    echo ""
        if [ -d $QDC_HOME/dcaasIntegration ]
        then
            echo "Info: $QDC_HOME/dcaasIntegration already exists, not re-creating"
            echo ""
        else
            mkdir -p "$QDC_HOME/dcaasIntegration/qdc-xmlstore"
            echo "Info: Directory $QDC_HOME/dcaasIntegration created"
            echo ""
        fi
fi


if [ ! $UPGRADEMODE ]
then
    create_setenv.sh
    update_startup.sh
    if [[ $INSTALL_TYPE != "SINGLE" && $INSTALL_TYPE != "DOCKER" ]]
    then
        update_catalina.properties
    fi
fi

# For upgrades copy /WEB-INF/lib folder into $TOMCAT_HOME/backups
if [ $UPGRADEMODE ]
then
    if [ ! -d $TOMCAT_HOME/backups ]
    then
        mkdir "$TOMCAT_HOME/backups"
    fi
    mkdir "$TOMCAT_HOME/backups/backup-$DATESTAMP"
    echo "Info: Backup of WEB-INF/classes being made at $TOMCAT_HOME/backups/backup-$DATESTAMP"
    echo ""
    cp $TOMCAT_HOME/webapps/$WEBAPP_NAME/WEB-INF/classes/*  $TOMCAT_HOME/backups/backup-$DATESTAMP 2>/dev/null
fi

# Clean webapps of old installations and move anything left to offline-webapps
if [ -d $TOMCAT_HOME/webapps/$WEBAPP_NAME ]
then
   echo "Previous $WEBAPP_NAME folder found in webapps, deleting..."
   rm -fr $TOMCAT_HOME/webapps/$WEBAPP_NAME
fi

if [ -e $TOMCAT_HOME/webapps/$WEBAPP_NAME.war ]
then
   echo "Previous $WEBAPP_NAME.war found, deleting..."
   rm $TOMCAT_HOME/webapps/$WEBAPP_NAME.war
fi

# If there is anything else in webapps move it to offline-webapps
if [ "$(ls -A $TOMCAT_HOME/webapps)" ]
then
    if [ ! -d $TOMCAT_HOME/offline-webapps ]
    then
	echo "Creating offline-webapps folder"
        mkdir "$TOMCAT_HOME/offline-webapps"
    fi
    echo "Moving contents of webapps to offline-webapps"
    mv $TOMCAT_HOME/webapps/* $TOMCAT_HOME/offline-webapps
fi

# Create installation folder under TOMCAT_HOME
if [[ $INSTALL_TYPE == "HDP" || $INSTALL_TYPE == "CDH" || $INSTALL_TYPE == "EMR" || $INSTALL_TYPE == "SINGLE" ]]
then

    if [ ! -d $TOMCAT_HOME/QDCinstaller ]
    then
        mkdir "$TOMCAT_HOME/QDCinstaller"
        echo "-------------------------------"
        echo "Creating installation directory"
        echo "-------------------------------"
    else
        rm -rf $TOMCAT_HOME/QDCinstaller
        mkdir "$TOMCAT_HOME/QDCinstaller"
        echo "-------------------------------------------------------------------------"
        echo "Removing old installation directory & creating new installation directory"
        echo "-------------------------------------------------------------------------" 
    fi

else
    echo "-----------------------------"
    echo "Docker installation type"
    echo "-----------------------------"

fi

    echo ""
    echo "-----------------------------------------------"
    echo "Setting up Qlik Data Catalyst                  "
    echo "-----------------------------------------------"

#if [[ $INSTALL_TYPE == "HDP" || $INSTALL_TYPE == "CDH" || $INSTALL_TYPE == "EMR" || $INSTALL_TYPE == "SINGLE" ]]
if [[ $INSTALL_TYPE != "DOCKER" ]]
then
    unzip -qo $PODIUM_RELEASE_FILE -d $TOMCAT_HOME/QDCinstaller
    cd $TOMCAT_HOME/QDCinstaller || error_exit "Error: cannot change directory to $TOMCAT_HOME/QDCinstaller"
fi

if [ $INSTALL_TYPE == "DOCKER" ]
then
    cd /tmp/QDCinstaller || error_exit "Error: cannot change directory to /tmp/QDCinstaller"
fi

if [[ $INSTALL_TYPE == "SINGLE" || $INSTALL_TYPE == "DOCKER" ]]
then
    # For Single server use this WAR file
    # war was originally podium_cloudera-cdh5.war, is now qdc_linux.war
    if [[ $INSTALL_TYPE == "SINGLE" ]]
    then
        if [[ -f "$TOMCAT_HOME/QDCinstaller/podium/lib/podium_cloudera-cdh5.war" ]]; then
            cp $TOMCAT_HOME/QDCinstaller/podium/lib/podium_cloudera-cdh5.war $TOMCAT_HOME/webapps/$WEBAPP_NAME.war
        else
            cp $TOMCAT_HOME/QDCinstaller/podium/lib/qdc_linux.war $TOMCAT_HOME/webapps/$WEBAPP_NAME.war
        fi
    fi
    if [[ $INSTALL_TYPE == "DOCKER" ]]
    then
        cp /tmp/QDCinstaller/podium/lib/qdc_linux.war $TOMCAT_HOME/webapps/$WEBAPP_NAME.war
    fi
else
    # For all other installs use this WAR file
    cp $TOMCAT_HOME/QDCinstaller/podium/lib/podium_localhadoop.war $TOMCAT_HOME/webapps/$WEBAPP_NAME.war
fi


# Create podiumLib folders in $TOMCAT_HOME and copy over 3rd party jars
if [[ $INSTALL_TYPE != "SINGLE" && $INSTALL_TYPE != "DOCKER" ]]
then
    if [ ! -d $TOMCAT_HOME/podiumLibPreHadoop ]
    then
        mkdir "$TOMCAT_HOME/podiumLibPreHadoop"
    fi
    if [ ! -d $TOMCAT_HOME/podiumLibPostHadoop ]
    then
        mkdir "$TOMCAT_HOME/podiumLibPostHadoop"
    fi
    cp $TOMCAT_HOME/QDCinstaller/podium/thirdParty/kryo-2.21.jar $TOMCAT_HOME/podiumLibPostHadoop
    if [[ $HDP_VERSION == 3* ]]
    then
        cp $TOMCAT_HOME/QDCinstaller/podium/thirdParty/hive-shims-0.20S-1.2.1.jar $TOMCAT_HOME/podiumLibPostHadoop
        cp $TOMCAT_HOME/QDCinstaller/podium/thirdParty/hive-shims-common-1.2.1.jar $TOMCAT_HOME/podiumLibPostHadoop
        cp $TOMCAT_HOME/QDCinstaller/podium/thirdParty/kafka-clients-1.1.0.jar $TOMCAT_HOME/podiumLibPreHadoop
    fi
fi

# For all installations create $QDC_HOME/source & $QDC_HOME/publish directories
if [ -d $QDC_HOME/source ]
    then
        echo "Info: $QDC_HOME/source already exists, not re-creating"
        echo ""
    else
        mkdir -p "$QDC_HOME/source"
        echo "Info: Directory $QDC_HOME/source created"
        echo ""
fi
if [ -d $QDC_HOME/publish ]
    then
        echo "Info: $QDC_HOME/publish already exists, not re-creating"
        echo ""
    else
        mkdir -p "$QDC_HOME/publish"
        echo "Info: Directory $QDC_HOME/publish created"
        echo ""
fi

# For CDH 6 installations - copy hive-shims-0.20S-1.2.1.jar and hive-shims-common-1.2.1.jar

if [[ $INSTALL_TYPE == "CDH" && $HADOOP_VERSION == *"cdh6"* ]]
then
        cp $TOMCAT_HOME/QDCinstaller/podium/thirdParty/hive-shims-0.20S-1.2.1.jar $TOMCAT_HOME/podiumLibPostHadoop
        cp $TOMCAT_HOME/QDCinstaller/podium/thirdParty/hive-shims-common-1.2.1.jar $TOMCAT_HOME/podiumLibPostHadoop
fi


# Copy Publish To Qlik integration files to $QDC_HOME/qlikpublish.  
# (Upgrade mode will create a backup of the top-level scripts).

if [[ $ENABLE_SENSE_INTEGRATION == "TRUE" ]]
then
    if [ $UPGRADEMODE ]
    then
        if [ ! -d $QDC_HOME/backups/qlikpublish ]
        then
            mkdir -p "$QDC_HOME/backups/qlikpublish"
        fi
        if [ ! -d $QDC_HOME/backups/qlikcore ]
        then
            mkdir -p "$QDC_HOME/backups/qlikcore"
        fi
        mkdir "$QDC_HOME/backups/qlikpublish/backup-$DATESTAMP"
        mkdir "$QDC_HOME/backups/qlikcore/backup-$DATESTAMP"
        echo ""
        echo "Info: Backup of QlikPublish scripts being made at $QDC_HOME/backups/qlikpublish/backup-$DATESTAMP"
        echo ""
        cp $QDC_HOME/qlikpublish/*.js  $QDC_HOME/backups/qlikpublish/backup-$DATESTAMP 2>/dev/null
        echo ""
        echo "Info: Backup of QlikCore scripts being made at $QDC_HOME/backups/qlikcore/backup-$DATESTAMP"
        echo ""
        cp $QDC_HOME/qlikcore/{*.js,*.sh}  $QDC_HOME/backups/qlikcore/backup-$DATESTAMP 2>/dev/null
        
    fi
    echo ""
    echo "-----------------------------------------------"
    echo "Setting up Publish To Qlik integration scripts "
    echo "-----------------------------------------------"
    echo ""
    cp podium/bin/*.js $QDC_HOME/qlikpublish
    #cp podium/bin/createQlikApp.js $QDC_HOME/qlikpublish
    #cp podium/bin/updateExistingApp.js $QDC_HOME/qlikpublish
    cp podium/bin/package.json $QDC_HOME/qlikpublish
    chmod 744 $QDC_HOME/qlikpublish/*.js

#   Use NPM For Publish To Qlik 
        if hash node 2>/dev/null; then
            if hash npm 2>/dev/null; then
                cd $QDC_HOME/qlikpublish || error_exit "Error: cannot change directory to $QDC_HOME/qlikpublish"
                if [ -d node_modules ]
                then
                    echo "Info: Publish To Qlik node modules already installed"
                    echo ""
                else
                    echo "Info: installing node modules for Publish To Qlik -- output to npm.log"
                    npm install --only=prod > npm.log 2>&1
                    NPM_CHECK=$?
                    if [[ $NPM_CHECK == 0 ]]
                    then
                        echo "Info: Publish To Qlik node modules successfully installed, listing"
                        echo ""
                        npm ls
                        # 4.2-13466 required the following path to be replaced; this is no longer the case
                        #sed -ri "s|node /usr/local/podium/qlikcore|node $QDC_HOME/qlikpublish|" $QDC_HOME/qlikcore/qdc_qvd_2_csv.sh
                    else
                        echo "Error: npm install unsuccessful, exit code: $NPM_CHECK, see npm.log"
                        exit 1
                    fi
                fi
            else
                echo "Error: npm not found, was Node.js installed per the installation guide?"
                exit 1
            fi
            else
                echo "Error: node not found, was Node.js installed per the installation guide?"
                exit 1
            fi
        fi
    
# DCAAS XML Integration
#
# Copy DCAAS integration files to $QDC_HOME/dcaasIntegration.
# Upgrade mode will create a backup of the top-level scripts.
#
# Backup IF upgrade mode.  
if [ $UPGRADEMODE ]
then
    if [ ! -d $QDC_HOME/backups/dcaasIntegration ]
    then
        mkdir -p "$QDC_HOME/backups/dcaasIntegration"
    fi
    mkdir "$QDC_HOME/backups/dcaasIntegration/backup-$DATESTAMP"
    echo ""
    echo "Info: Backup of DCAAS Integration scripts being made at $QDC_HOME/backups/dcaasIntegration/backup-$DATESTAMP"
    echo ""
    cp $QDC_HOME/dcaasIntegration/*.*  $QDC_HOME/backups/dcaasIntegration/backup-$DATESTAMP 2>/dev/null
fi

# Copy DCAAS Files

if [[ $ENABLE_NEXTGEN_XML == "TRUE" ]]
then
    echo ""
    echo "-----------------------------------------------"
    echo "Setting up Qlik Nextgen XML Integration Files"
    echo "-----------------------------------------------"
    echo ""
    if [ -d $QDC_HOME/dcaasIntegration ]
        then
            echo ""
            echo "Info: $QDC_HOME/dcaasIntegration already exists - will not overwrite existing files."
            echo ""
        else
            cp $TOMCAT_HOME/QDCinstaller/podium/bin/dcaasIntegration/* $QDC_HOME/dcaasIntegration
            chmod 744 $QDC_HOME/dcaasIntegration/*.sh
            # Update docker-compose.dcaas-connectors.yml with container image version        
            sed -i "s|image: qlik/dcaas:.*|image: qlik/dcaas:$DCAAS_IMAGE_VERSION|" $QDC_HOME/dcaasIntegration/docker-compose.dcaas-connectors.yml
            sed -i "s|image: qliktech-docker.jfrog.io/data-connector-rest:.*|image: qliktech-docker.jfrog.io/data-connector-rest:$DATA_CONNECTOR_REST_IMAGE_VERSION|" $QDC_HOME/dcaasIntegration/docker-compose.dcaas-connectors.yml
    fi


#    cp $TOMCAT_HOME/QDCinstaller/podium/bin/dcaasIntegration/* $QDC_HOME/dcaasIntegration
#    chmod 744 $QDC_HOME/dcaasIntegration/*.sh

# Update docker-compose.dcaas-connectors.yml with container image version        
#    sed -i "s|image: qlik/dcaas:.*|image: qlik/dcaas:$DCAAS_IMAGE_VERSION|" $QDC_HOME/dcaasIntegration/docker-compose.dcaas-connectors.yml
#    sed -i "s|image: qliktech-docker.jfrog.io/data-connector-rest:.*|image: qliktech-docker.jfrog.io/data-connector-rest:$DATA_CONNECTOR_REST_IMAGE_VERSION|" $QDC_HOME/dcaasIntegration/docker-compose.dcaas-connectors.yml


# Create Context docBase for Tomcat server.xml
#    sed '/^unpackWARs="true" autoDeploy="true"/ s/$/ <Context docBase="$QDC_HOME/dcaasIntegration/qdc-xmlstore" path="/qdc-xmlstore"/>' $TOMCAT_HOME/conf/server.xml

fi

# unzip WAR files (instead of relying on Java to do it)
echo ""
echo "-------------------------------------------------"
echo "Unzipping WAR files (this may take a few minutes)"
echo "-------------------------------------------------"
echo ""
cd $TOMCAT_HOME/webapps || error_exit "Error: cannot change directory to $TOMCAT_HOME/webapps"

if [ ! -d $WEBAPP_NAME ]
then
    mkdir "$WEBAPP_NAME"
fi 
unzip -q -o $WEBAPP_NAME.war -d $WEBAPP_NAME/

# Assembla 12526 -- for multi-node (aka localhadoop, aka cluster installs), move or remove slf4j bindings to log4j
if [[ $INSTALL_TYPE == "CDH" || $INSTALL_TYPE == "EMR" ]]
then
    rm $TOMCAT_HOME/webapps/$WEBAPP_NAME/WEB-INF/lib/slf4j-api-1.7.8.jar
    rm $TOMCAT_HOME/webapps/$WEBAPP_NAME/WEB-INF/lib/slf4j-log4j12-1.7.8.jar
fi
if [[ $INSTALL_TYPE == "HDP" && $HDP_VERSION == 2* ]]
then
    rm $TOMCAT_HOME/webapps/$WEBAPP_NAME/WEB-INF/lib/slf4j-api-1.7.8.jar
    rm $TOMCAT_HOME/webapps/$WEBAPP_NAME/WEB-INF/lib/slf4j-log4j12-1.7.8.jar
fi
if [[ $INSTALL_TYPE == "HDP" && $HDP_VERSION == 3* ]]
then
    mv $TOMCAT_HOME/webapps/$WEBAPP_NAME/WEB-INF/lib/slf4j-api-1.7.8.jar $TOMCAT_HOME/podiumLibPreHadoop/
    mv $TOMCAT_HOME/webapps/$WEBAPP_NAME/WEB-INF/lib/slf4j-log4j12-1.7.8.jar $TOMCAT_HOME/podiumLibPreHadoop/
fi

if [[ $INSTALL_TYPE == "CDH" && $HADOOP_VERSION == *"cdh6"* ]]
then
    # Assembla 12253 -- remove pig shipped with QDC
    rm $TOMCAT_HOME/webapps/$WEBAPP_NAME/WEB-INF/lib/pig-0.16.0-podium.jar
    
    # Assembla 12253 -- setup tez jars
    cd $TOMCAT_HOME/podiumLibPostHadoop || error_exit "Error: cannot change directory to $TOMCAT_HOME/podiumLibPostHadoop"
    tar -zxf $TOMCAT_HOME/QDCinstaller/podium/thirdParty/tez-0.9.2-cdh-6.tar.gz lib/commons-collections4-4.1.jar tez-api-0.9.2.jar tez-dag-0.9.2.jar tez-runtime-internals-0.9.2.jar tez-yarn-timeline-history-0.9.2.jar tez-common-0.9.2.jar tez-mapreduce-0.9.2.jar tez-runtime-library-0.9.2.jar tez-yarn-timeline-history-with-acls-0.9.2.jar
    mv lib/commons-collections4-4.1.jar .
    rm -fr lib/
fi

if [ $UPGRADEMODE ]
then
    cp $TOMCAT_HOME/backups/backup-$DATESTAMP/log4j.xml $TOMCAT_HOME/webapps/$WEBAPP_NAME/WEB-INF/classes
    if [ -d $QDC_HOME/qlikcore ]
    then
        if [ ! -f $QDC_HOME/qlikcore/qdc-qlik-core-feb-2020.tar ]
        then
            echo "Info: Updating Qlik Core Engine Docker container and docker-compose YML file"
            echo ""
            cp $TOMCAT_HOME/QDCinstaller/podium/bin/qlikSenseIntegration/qdc-qlik-core-feb-2020.tar $QDC_HOME/qlikcore/
            cp -f $TOMCAT_HOME/QDCinstaller/podium/bin/qlikSenseIntegration/docker-qdc-qlik-core.yml $QDC_HOME/qlikcore/
        fi
    fi
else
    if [[ $INSTALL_TYPE != "DOCKER" ]]
    then
        cp $TOMCAT_HOME/QDCinstaller/podium/config/log4j.xml $TOMCAT_HOME/webapps/$WEBAPP_NAME/WEB-INF/classes

        mkdir -p "$QDC_HOME/qlikcore"
        MKDIR_CHECK=$?
        if [[ $MKDIR_CHECK != 0 ]]
        then
            echo "Error: Could not create $QDC_HOME/qlikcore"
            exit 1
        fi
        cp $TOMCAT_HOME/QDCinstaller/podium/bin/qlikSenseIntegration/* $QDC_HOME/qlikcore/
    fi

    if [[ $INSTALL_TYPE == "DOCKER" ]]
    then
        cp /tmp/QDCinstaller/podium/config/log4j.xml $TOMCAT_HOME/webapps/$WEBAPP_NAME/WEB-INF/classes

        mkdir -p "$QDC_HOME/qlikcore"
        MKDIR_CHECK=$?
        if [[ $MKDIR_CHECK != 0 ]]
        then
            echo "Error: Could not create $QDC_HOME/qlikcore"
            exit 1
        fi
        cp /tmp/QDCinstaller/podium/bin/qlikSenseIntegration/* $QDC_HOME/qlikcore/
    fi

#
    if [[ $INSTALL_TYPE == "SINGLE" || $INSTALL_TYPE == "DOCKER" ]]
    then
        mkdir -p "$PODIUM_BASE"
        MKDIR_CHECK=$?
        if [[ $MKDIR_CHECK == 0 ]]
        then
            chmod -R 770 "$PODIUM_BASE"
            CHMOD_CHECK=$?
            if [[ $CHMOD_CHECK != 0 ]]
            then
                echo "WARNING: Could not change permission on $PODIUM_BASE"
                problem_found=true
            fi
        else
            echo "WARNING: Could not create $PODIUM_BASE"
            problem_found=true
        fi
    fi
fi

# Update core_env.properties
if [ ! $UPGRADEMODE ]
then
    update_core_env.properties
fi

if [ $SILENTMODE ]
then
    postgres_check
fi

# Configure PostgreSQL
if [ ! $UPGRADEMODE ]
then
    echo "---------------"
    echo "podium_md setup"
    echo "---------------"
    echo ""

    configure_podium_md
fi

# podium_dist setup occurs on both first install and upgrade
if [[ $INSTALL_TYPE == "SINGLE" || $INSTALL_TYPE == "DOCKER" ]]
then
    echo ""
    echo "-----------------"
    echo "podium_dist setup"
    echo "-----------------"
    echo ""

    WHICH_PSQL=$(command -v psql)
    PSQL_DIR=$(readlink -f $WHICH_PSQL)
    #echo $PSQL_DIR
    PG_DIR=$(echo $PSQL_DIR | sed "s:/bin/psql::")
    #echo $PG_DIR
    FILE_FDW=$PG_DIR/lib/file_fdw.so
    if [ -f $FILE_FDW ]
    then
        echo "Info: file_fdw exists at $FILE_FDW"

        configure_podium_dist
    else
        echo "Error: file_fdw not found at $FILE_FDW"
        exit 1
    fi
fi

#  Setup Qlik Sense Integration using QlikCore Docker Image

if [[ ! $INSTALL_TYPE == "DOCKER" ]]
then
    if [[ $ENABLE_SENSE_INTEGRATION == "TRUE" ]]
    then
        echo ""
        echo "---------------"
        echo "Qlik Core setup"
        echo "---------------"
        echo ""

        configure_qlik_integration
    else
        echo ""
        echo "------------------------"
        echo "Skipping Qlik Core Setup"
        echo "------------------------"
        echo ""
    fi
fi

if [ $INSTALL_TYPE == "DOCKER" ]
then
    cp /tmp/install/version_build.properties /usr/local/qdc
    cp /tmp/install/version_build.properties $TOMCAT_HOME/conf/backup_version_build.properties

    sed -i "s/localhost:19076/core:9076/g" /usr/local/qdc/qlikcore/qvd_2_csv_transformer.js
    sed -i "s/localhost:19076/core:9076/g" /usr/local/qdc/qlikcore/csv_2_qvd_transformer.js 
    cp /tmp/install/qdc_qvd_2_csv.sh /usr/local/qdc/qlikcore
    cp /tmp/install/qdc_csv_2_qvd.sh /usr/local/qdc/qlikcore
    (cd /usr/local/qdc/qlikcore && npm install --only=prod)
fi

#  DCAAS
#
if [[ ! $UPGRADEMODE || ! $INSTALL_TYPE == "DOCKER" ]]
then
    if [[ $ENABLE_NEXTGEN_XML == "TRUE" ]]
    then
        echo ""
        echo "--------------------------------"
        echo "Qlik Nextgen XML Connector Setup"
        echo "--------------------------------"
        echo ""
    
        configure_dcaas_integration
    else
        echo ""
        echo "-------------------------------------"
        echo "Skipping Nextgen XML Connector Setup "
        echo "-------------------------------------"
        echo ""
    fi
fi
# modify QVD load script for EMR installations
    if [ $INSTALL_TYPE == EMR ]
    then
        sed -i 's|hadoop fs -copyFromLocal "$csv_temp_folder_path/$qvd_file_name.$current_time.csv" "$3"|hadoop fs -copyFromLocal "$csv_temp_folder_path/$qvd_file_name.$current_time.csv" "$4"|' $QDC_HOME/qlikcore/qdc_qvd_2_csv.sh
    fi

# Security - hide Tomcat version information display within error pages
    mkdir -p $TOMCAT_HOME/lib/org/apache/catalina/util
    echo "server.info=Unknown Application Server" > $TOMCAT_HOME/lib/org/apache/catalina/util/ServerInfo.properties

# Remove installation folder
 rm -rf $TOMCAT_HOME/QDCinstaller/

# Call summary subroutine and exit script
echo ""
summary
echo ""
exit 0

